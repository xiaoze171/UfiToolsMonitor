define(["jquery","knockout","config/config","service","underscore"],function(n,i,e,c,o){function r(){}function t(){var e=new r;i.applyBindings(e,n("#container")[0])}return{init:t}});
//# sourceMappingURL=../../sourcemaps/adm/developer_options.js.map
