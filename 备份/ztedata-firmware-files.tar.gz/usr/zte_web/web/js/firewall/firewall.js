define(["jquery","knockout","config/config","service","underscore"],function(n,e,i,o,r){function c(){var n=this;n.hasBattery=i.HAS_BATTERY,n.isCPE=-1!=i.DEVICE.toLowerCase().indexOf("cpe")}function t(){var i=n("#container");e.cleanNode(i[0]);var o=new c;e.applyBindings(o,i[0])}return{init:t}});
//# sourceMappingURL=../../sourcemaps/firewall/firewall.js.map
